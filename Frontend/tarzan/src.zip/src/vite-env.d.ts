/// <reference types="vite/client" />
export default defineConfig({
  plugins: [vue(), tsconfigPaths()],
});
