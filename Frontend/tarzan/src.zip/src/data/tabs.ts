export interface Tab {
  name: string;
  component: any;
}
