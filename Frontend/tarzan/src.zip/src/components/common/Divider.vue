<template>
  <div>
    <hr>
  </div>
</template>
<script>
export default {
  
}
</script>
<style lang="scss" scoped>
hr {
  border: none; 
  height: 1px; 
  background-color: $secondary-color-75; 
  margin: 0;
}
</style>