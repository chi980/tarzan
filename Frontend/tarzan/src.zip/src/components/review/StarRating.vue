<template>
  <div class="star-rating">
    <ul class="star-list">
      
      <li v-for="n in repeatCount" 
        :key="n" 
        class="star" 
        @click="!readonly && rate(n)">
        
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          :class="{ 'active': n <= modelValue }"
          fill="currentColor"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M14.4399 4.53675L15.0999 6.53675C15.3982 7.46244 16.2574 8.09174 17.2299 8.09675H19.3099C20.2854 8.09056 21.1528 8.7164 21.4544 9.64412C21.756 10.5718 21.4226 11.5881 20.6299 12.1568L18.9199 13.3968C18.1328 13.9682 17.802 14.9808 18.0999 15.9068L18.7599 17.9068C19.0864 18.8359 18.7677 19.8692 17.9746 20.4531C17.1816 21.037 16.1002 21.0344 15.3099 20.4468L13.6299 19.1968C12.8424 18.6262 11.7775 18.6262 10.9899 19.1968L9.30993 20.4468C8.52407 21.0219 7.45662 21.0235 6.66913 20.4505C5.88163 19.8776 5.55454 18.8615 5.85993 17.9368L6.51993 15.9368C6.81789 15.0108 6.48709 13.9982 5.69993 13.4268L3.94993 12.1668C3.14123 11.5969 2.80211 10.5641 3.11564 9.62575C3.42918 8.68745 4.32111 8.06595 5.30993 8.09675H7.38993C8.35713 8.09459 9.21473 7.47454 9.51993 6.55675L10.1799 4.55675C10.4758 3.63296 11.3327 3.00458 12.3027 3.00002C13.2727 2.99547 14.1354 3.61578 14.4399 4.53675Z"
          />
        </svg>

      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, defineProps, defineEmits } from 'vue';

const props = defineProps({
  modelValue: Number, // 현재 별점 값 (v-model 사용)
  readonly: Boolean,  // 읽기 전용 모드 여부
});

const emit = defineEmits(['update:modelValue']);

const repeatCount = ref(5);
// const currentRating = ref(4);
const rate = (n) => {
  emit('update:modelValue', n)
}
</script>

<style lang="scss" scoped>
.star-rating .star-list {
  display: inline-flex;
}

.star {
  cursor: pointer; /* 클릭 가능한 커서로 변경 (추가됨) */
  margin-right: 5px;
}

.star svg {
  width: 24px;
  height: 24px;
  fill: #EDEDED; /* 기본 색상 */
}

.star svg.active {
  fill: red; /* 선택된 별을 빨간색으로 변경 (추가됨) */
}
</style>