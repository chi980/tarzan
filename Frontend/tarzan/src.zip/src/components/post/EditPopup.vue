<template>
  <div class="EditPopup">
    <slot name="button"></slot>
    
  </div>
</template>
<script>
export default {
  
}
</script>
<style lang="">
  
</style>