// types.d.ts
declare module "*.svg" {
  const content: any;
  export default content;
}
