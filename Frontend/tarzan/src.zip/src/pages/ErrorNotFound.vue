<script setup></script>
<template>
  <span>404 NOT FOUND</span>
</template>
<style scoped></style>
